<?php

define("ROOT_PATH", realpath(dirname(__FILE__)));
define("BASE_URL", "http://localhost/agenda");
