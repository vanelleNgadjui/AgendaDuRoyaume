<div class="left-sidebar">
    <ul>
        <li><a href="<?php echo BASE_URL . '/admin/posts/index.php'; ?>">Gerer les évenements</a></li>
        <li><a href="<?php echo BASE_URL . '/admin/topics/index.php'; ?>">Gerer Topics</a></li>
        <li><a href="<?php echo BASE_URL . '/admin/products/index.php'; ?>">Gerer Produits</a></li>
        <li><a href="<?php echo BASE_URL . '/admin/users/index.php'; ?>">Gerer Users</a></li>
    </ul>
</div>